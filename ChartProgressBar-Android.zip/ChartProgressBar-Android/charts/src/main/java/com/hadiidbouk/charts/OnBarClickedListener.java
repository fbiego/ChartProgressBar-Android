package com.hadiidbouk.charts;

public interface OnBarClickedListener {
	void onBarClicked(int index);
}
